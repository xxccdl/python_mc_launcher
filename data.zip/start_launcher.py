import tkinter
import customtkinter
import subprocess
import threading
import json
import os
import psutil
import uuid
import sys
import requests  # 新增依赖
from pathlib import Path
from tkinter import messagebox, filedialog

# 核心依赖库
import minecraft_launcher_lib

# --- 全局常量 ---
APP_NAME = "Python MC Pro Launcher v8 (Ecosystem)"
MINECRAFT_DIR = Path.home() / ".python_mc_pro_launcher"
CONFIG_FILE = MINECRAFT_DIR / "config.json"
MODRINTH_API_URL = "https://api.modrinth.com/v2/"

# --- 配置管理 ---
class ConfigManager:
    def __init__(self, file_path ):
        self.file_path = Path(file_path)
        self.config = {}
        self.default_config = {
            "accounts": [{"username": "Player", "uuid": str(uuid.uuid4())}],
            "selected_account_uuid": None,
            "java_path": "",
            "memory_mb": self.get_default_memory(),
            "jvm_args": ""
        }
        self.load()

    def get_default_memory(self):
        try:
            total_mem = psutil.virtual_memory().total / (1024**2)
            return max(2048, min(8192, int(total_mem / 4)))
        except:
            return 2048

    def load(self):
        if self.file_path.exists():
            try:
                with open(self.file_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                for key, value in self.default_config.items():
                    self.config.setdefault(key, value)
            except (json.JSONDecodeError, IOError):
                self.config = self.default_config
        else:
            self.config = self.default_config
        
        if not self.config.get("selected_account_uuid") and self.config.get("accounts"):
            self.config["selected_account_uuid"] = self.config["accounts"][0]["uuid"]
        return self.config

    def save(self):
        os.makedirs(self.file_path.parent, exist_ok=True)
        with open(self.file_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=4)

    def get(self, key, default=None):
        return self.config.get(key, default)

    def set(self, key, value):
        self.config[key] = value

# --- 游戏日志窗口 ---
class LogWindow(customtkinter.CTkToplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("游戏实时日志")
        self.geometry("800x600")
        self.log_textbox = customtkinter.CTkTextbox(self, state="disabled", wrap="word", font=("Consolas", 12))
        self.log_textbox.pack(padx=10, pady=10, fill="both", expand=True)
    def add_log_message(self, message):
        self.after(0, self._insert_message, message)
    def _insert_message(self, message):
        if not self.winfo_exists(): return
        self.log_textbox.configure(state="normal")
        self.log_textbox.insert("end", message)
        self.log_textbox.see("end")
        self.log_textbox.configure(state="disabled")
    def clear_logs(self):
        if not self.winfo_exists(): return
        self.log_textbox.configure(state="normal")
        self.log_textbox.delete("1.0", "end")
        self.log_textbox.configure(state="disabled")

# --- 版本安装窗口 ---
class VersionInstallWindow(customtkinter.CTkToplevel):
    def __init__(self, master, callback):
        super().__init__(master)
        self.title("安装新版本")
        self.geometry("400x500")
        self.transient(master)
        self.grab_set()
        self.install_callback = callback
        self.release_versions = []
        self.snapshot_versions = []
        self.tab_view = customtkinter.CTkTabview(self)
        self.tab_view.pack(padx=10, pady=10, fill="both", expand=True)
        self.tab_view.add("正式版")
        self.tab_view.add("快照版")
        self.release_listbox = tkinter.Listbox(self.tab_view.tab("正式版"), bg="#2B2B2B", fg="white", selectbackground="#1F6AA5", borderwidth=0, highlightthickness=0)
        self.release_listbox.pack(padx=5, pady=5, fill="both", expand=True)
        self.snapshot_listbox = tkinter.Listbox(self.tab_view.tab("快照版"), bg="#2B2B2B", fg="white", selectbackground="#1F6AA5", borderwidth=0, highlightthickness=0)
        self.snapshot_listbox.pack(padx=5, pady=5, fill="both", expand=True)
        self.install_button = customtkinter.CTkButton(self, text="安装选中版本", command=self.on_install)
        self.install_button.pack(padx=10, pady=10, fill="x")
        self.status_label = customtkinter.CTkLabel(self, text="正在获取版本列表...")
        self.status_label.pack(padx=10, pady=5)
        threading.Thread(target=self.load_versions, daemon=True).start()
    def load_versions(self):
        try:
            version_list = minecraft_launcher_lib.utils.get_version_list()
            for v in version_list:
                if v['type'] == 'release': self.release_versions.append(v['id'])
                elif v['type'] == 'snapshot': self.snapshot_versions.append(v['id'])
            self.after(0, self.populate_lists)
        except Exception as e:
            self.after(0, lambda: self.status_label.configure(text=f"获取列表失败: {e}"))
    def populate_lists(self):
        for v in self.release_versions: self.release_listbox.insert('end', v)
        for v in self.snapshot_versions: self.snapshot_listbox.insert('end', v)
        self.status_label.configure(text="请选择要安装的版本")
    def on_install(self):
        selected_version = None
        current_tab = self.tab_view.get()
        if current_tab == "正式版" and self.release_listbox.curselection(): selected_version = self.release_listbox.get(self.release_listbox.curselection())
        elif current_tab == "快照版" and self.snapshot_listbox.curselection(): selected_version = self.snapshot_listbox.get(self.snapshot_listbox.curselection())
        if selected_version:
            self.install_button.configure(state="disabled", text="正在通知主窗口...")
            self.install_callback(selected_version)
            self.destroy()
        else:
            messagebox.showwarning("提示", "请先选择一个版本！", parent=self)

# --- Mod市场窗口 ---
class ModMarketWindow(customtkinter.CTkToplevel):
    def __init__(self, master, mc_version, mods_dir):
        super().__init__(master)
        self.title(f"Mod 市场 (Minecraft {mc_version})")
        self.geometry("800x600")
        self.transient(master)
        self.grab_set()

        self.mc_version = mc_version
        self.mods_dir = Path(mods_dir)
        self.master_app = master

        search_frame = customtkinter.CTkFrame(self)
        search_frame.pack(padx=10, pady=10, fill="x")
        self.search_entry = customtkinter.CTkEntry(search_frame, placeholder_text="搜索 Mod...")
        self.search_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.search_button = customtkinter.CTkButton(search_frame, text="搜索", command=self.search_mods)
        self.search_button.pack(side="left")

        self.results_frame = customtkinter.CTkScrollableFrame(self, label_text="搜索结果")
        self.results_frame.pack(padx=10, pady=10, fill="both", expand=True)

    def search_mods(self):
        query = self.search_entry.get()
        if not query: return
        
        for widget in self.results_frame.winfo_children(): widget.destroy()
        customtkinter.CTkLabel(self.results_frame, text="正在搜索...").pack()
        self.search_button.configure(state="disabled", text="搜索中...")
        
        threading.Thread(target=self._search_thread, args=(query,), daemon=True).start()

    def _search_thread(self, query):
        try:
            params = {'query': query, 'facets': f'[["versions:{self.mc_version}"]]'}
            response = requests.get(f"{MODRINTH_API_URL}search", params=params)
            response.raise_for_status()
            results = response.json()['hits']
            self.after(0, self.display_results, results)
        except Exception as e:
            self.after(0, lambda: messagebox.showerror("错误", f"搜索失败: {e}", parent=self))
        finally:
            self.after(0, lambda: self.search_button.configure(state="normal", text="搜索"))

    def display_results(self, results):
        for widget in self.results_frame.winfo_children(): widget.destroy()
        if not results:
            customtkinter.CTkLabel(self.results_frame, text="未找到任何结果。").pack()
            return

        for mod in results:
            mod_frame = customtkinter.CTkFrame(self.results_frame)
            mod_frame.pack(fill="x", pady=5, padx=5)
            
            info_text = f"{mod['title']}\n作者: {mod['author']} | 下载量: {mod.get('downloads', 0)}"
            title_label = customtkinter.CTkLabel(mod_frame, text=info_text, anchor="w", justify="left")
            title_label.pack(side="left", fill="x", expand=True, padx=10, pady=5)
            
            download_button = customtkinter.CTkButton(mod_frame, text="下载", width=80)
            download_button.pack(side="right", padx=10)
            download_button.configure(command=lambda m=mod, btn=download_button: self.download_mod(m, btn))

    def download_mod(self, mod_data, button):
        button.configure(state="disabled", text="...")
        # 使用主窗口的线程管理器来执行下载
        self.master_app.run_task_in_thread(self._download_thread, "下载Mod", mod_data, button)

    def _download_thread(self, mod_data, button):
        try:
            project_id = mod_data['project_id']
            self.master_app.update_status(f"正在为 {mod_data['title']} 寻找兼容文件...")
            
            params = {'game_versions': f'["{self.mc_version}"]', 'loaders': '["fabric", "forge", "quilt", "neoforge"]'}
            response = requests.get(f"{MODRINTH_API_URL}project/{project_id}/version", params=params)
            response.raise_for_status()
            versions = response.json()

            if not versions: raise Exception("未找到兼容的文件")

            latest_version = versions[0]
            file_to_download = latest_version['files'][0]
            download_url = file_to_download['url']
            filename = file_to_download['filename']
            
            self.master_app.update_status(f"开始下载 {filename}...")
            file_response = requests.get(download_url, stream=True)
            file_response.raise_for_status()

            os.makedirs(self.mods_dir, exist_ok=True)
            with open(self.mods_dir / filename, 'wb') as f:
                for chunk in file_response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            self.master_app.update_status(f"Mod '{filename}' 下载成功！")
            self.after(0, lambda: button.configure(text="完成", state="disabled"))
        except Exception as e:
            self.master_app.update_status(f"下载失败: {e}")
            self.after(0, lambda: button.configure(text="重试", state="normal"))

# --- 主应用UI ---
class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("950x650")
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

        self.config_manager = ConfigManager(CONFIG_FILE)
        self.install_window = None
        self.log_window = None
        self.mod_market_window = None
        self.is_task_running = False

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        self.create_ui()
        self.after(100, self.initialize)

    def create_ui(self):
        sidebar = customtkinter.CTkFrame(self, width=300)
        sidebar.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        sidebar.grid_rowconfigure(2, weight=1)
        customtkinter.CTkLabel(sidebar, text=APP_NAME, font=customtkinter.CTkFont(size=20, weight="bold")).grid(row=0, column=0, padx=20, pady=20)
        
        self.account_menu = customtkinter.CTkOptionMenu(sidebar, values=["无账户"], command=self.switch_account)
        self.account_menu.grid(row=1, column=0, padx=20, pady=10, sticky="ew")

        tabview = customtkinter.CTkTabview(sidebar)
        tabview.grid(row=2, column=0, padx=10, pady=10, sticky="nsew")
        tabview.add("账户管理")
        tabview.add("设置")
        self.create_account_tab(tabview.tab("账户管理"))
        self.create_settings_tab(tabview.tab("设置"))

        main_frame = customtkinter.CTkFrame(self)
        main_frame.grid(row=0, column=1, sticky="nsew", padx=(0, 10), pady=10)
        main_frame.grid_columnconfigure(0, weight=1)

        version_frame = customtkinter.CTkFrame(main_frame)
        version_frame.grid(row=0, column=0, columnspan=2, padx=20, pady=20, sticky="ew")
        version_frame.grid_columnconfigure(0, weight=1)
        self.version_option_menu = customtkinter.CTkOptionMenu(version_frame, values=[" "], command=self.on_version_select)
        self.version_option_menu.grid(row=0, column=0, padx=(0,10), pady=5, sticky="ew")
        self.refresh_button = customtkinter.CTkButton(version_frame, text="刷新", width=60, command=self.refresh_version_list)
        self.refresh_button.grid(row=0, column=1)

        installer_frame = customtkinter.CTkFrame(main_frame)
        installer_frame.grid(row=1, column=0, columnspan=2, padx=20, pady=10, sticky="ew")
        installer_frame.grid_columnconfigure((0,1,2), weight=1)
        self.install_vanilla_button = customtkinter.CTkButton(installer_frame, text="安装新版本", command=self.open_install_window)
        self.install_vanilla_button.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        self.install_fabric_button = customtkinter.CTkButton(installer_frame, text="安装 Fabric", command=lambda: self.install_mod_loader("fabric"))
        self.install_fabric_button.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        self.install_forge_button = customtkinter.CTkButton(installer_frame, text="安装 Forge", command=lambda: self.install_mod_loader("forge"))
        self.install_forge_button.grid(row=0, column=2, padx=5, pady=5, sticky="ew")

        folder_frame = customtkinter.CTkFrame(main_frame)
        folder_frame.grid(row=2, column=0, columnspan=2, padx=20, pady=10, sticky="ew")
        folder_frame.grid_columnconfigure((0,1,2), weight=1)
        self.open_gamedir_button = customtkinter.CTkButton(folder_frame, text="打开游戏目录", command=self.open_game_directory)
        self.open_gamedir_button.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        self.open_mods_button = customtkinter.CTkButton(folder_frame, text="打开Mods目录", command=self.open_mods_folder)
        self.open_mods_button.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        self.mod_market_button = customtkinter.CTkButton(folder_frame, text="Mod 市场", command=self.open_mod_market)
        self.mod_market_button.grid(row=0, column=2, padx=5, pady=5, sticky="ew")

        self.status_label = customtkinter.CTkLabel(main_frame, text="正在初始化...", wraplength=600, justify="left")
        self.status_label.grid(row=3, column=0, columnspan=2, padx=20, pady=10, sticky="w")
        self.progress_bar = customtkinter.CTkProgressBar(main_frame)
        self.progress_bar.grid(row=4, column=0, columnspan=2, padx=20, pady=10, sticky="ew")
        self.progress_bar.set(0)

        self.launch_button = customtkinter.CTkButton(main_frame, text="启动游戏", command=self.start_launch_process, height=40)
        self.launch_button.grid(row=5, column=0, columnspan=2, padx=20, pady=20, sticky="ew")

    def create_account_tab(self, tab):
        tab.grid_columnconfigure(0, weight=1)
        customtkinter.CTkLabel(tab, text="已存账户").pack(pady=5)
        self.account_listbox = tkinter.Listbox(tab, bg="#2B2B2B", fg="white", borderwidth=0, highlightthickness=0, selectbackground="#1F6AA5")
        self.account_listbox.pack(fill="x", padx=10, expand=True)
        account_btn_frame = customtkinter.CTkFrame(tab, fg_color="transparent")
        account_btn_frame.pack(fill="x", padx=10, pady=5)
        self.new_account_entry = customtkinter.CTkEntry(account_btn_frame, placeholder_text="新玩家名")
        self.new_account_entry.pack(side="left", fill="x", expand=True, padx=(0,5))
        customtkinter.CTkButton(account_btn_frame, text="+", width=30, command=self.add_account).pack(side="left", padx=(0,5))
        customtkinter.CTkButton(account_btn_frame, text="-", width=30, command=self.remove_account).pack(side="left")

    def create_settings_tab(self, tab):
        tab.grid_columnconfigure(1, weight=1)
        customtkinter.CTkLabel(tab, text="Java路径:").grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.java_path_entry = customtkinter.CTkEntry(tab, placeholder_text="留空则自动寻找")
        self.java_path_entry.grid(row=0, column=1, padx=10, pady=5, sticky="ew")
        customtkinter.CTkButton(tab, text="...", width=30, command=self.select_java_path).grid(row=0, column=2, padx=5)
        customtkinter.CTkLabel(tab, text="最大内存(MB):").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.memory_entry = customtkinter.CTkEntry(tab)
        self.memory_entry.grid(row=1, column=1, columnspan=2, padx=10, pady=5, sticky="ew")
        customtkinter.CTkLabel(tab, text="JVM参数:").grid(row=2, column=0, padx=10, pady=5, sticky="w")
        self.jvm_args_entry = customtkinter.CTkEntry(tab, placeholder_text="-XX:+UseG1GC")
        self.jvm_args_entry.grid(row=2, column=1, columnspan=2, padx=10, pady=5, sticky="ew")
        customtkinter.CTkButton(tab, text="保存设置", command=self.save_settings).grid(row=3, column=0, columnspan=3, pady=10)

    def initialize(self):
        self.load_settings()
        self.update_account_list()
        self.refresh_version_list()

    def update_status(self, text):
        self.after(0, lambda: self.status_label.configure(text=text))

    def update_progress(self, progress):
        self.after(0, lambda: self.progress_bar.set(progress / 100))

    def on_closing(self):
        if self.is_task_running:
            if messagebox.askyesno("确认", "有任务正在运行，确定要强制退出吗？"):
                self.destroy()
        else:
            self.save_settings()
            self.destroy()

    def set_task_running(self, is_running, task_name=""):
        self.is_task_running = is_running
        state = "disabled" if is_running else "normal"
        
        self.launch_button.configure(state=state, text="启动游戏" if not is_running else f"{task_name}中...")
        self.refresh_button.configure(state=state)
        self.install_vanilla_button.configure(state=state)
        self.account_menu.configure(state=state)
        
        self.on_version_select(self.version_option_menu.get())
        self.version_option_menu.configure(state=state)

    def on_version_select(self, selected_version):
        is_valid_version = selected_version and "未找到" not in selected_version
        state = "normal" if is_valid_version and not self.is_task_running else "disabled"
        
        self.install_fabric_button.configure(state=state)
        self.install_forge_button.configure(state=state)
        self.open_gamedir_button.configure(state=state)
        self.open_mods_button.configure(state=state)
        self.mod_market_button.configure(state=state)

    def open_directory(self, path):
        try:
            os.makedirs(path, exist_ok=True)
            if os.name == 'nt':
                os.startfile(path)
            elif sys.platform == 'darwin':
                subprocess.run(['open', path])
            else:
                subprocess.run(['xdg-open', path])
        except Exception as e:
            messagebox.showerror("错误", f"无法打开目录：{e}")

    def get_current_game_directory(self):
        version_id = self.version_option_menu.get()
        if not version_id or "未找到" in version_id:
            return None
        return MINECRAFT_DIR / "versions" / version_id

    def open_game_directory(self):
        path = self.get_current_game_directory()
        if path: self.open_directory(path)
        else: messagebox.showwarning("提示", "请先选择一个有效的游戏版本。")

    def open_mods_folder(self):
        path = self.get_current_game_directory()
        if path: self.open_directory(path / "mods")
        else: messagebox.showwarning("提示", "请先选择一个有效的游戏版本。")

    def open_install_window(self):
        if self.install_window is None or not self.install_window.winfo_exists():
            self.install_window = VersionInstallWindow(self, self.install_version)
        else:
            self.install_window.focus()

    def run_task_in_thread(self, task_func, task_name, *args):
        is_core_task = task_name != "下载Mod"
        if self.is_task_running and is_core_task:
            messagebox.showwarning("提示", "已有另一个核心任务正在运行，请稍后再试。")
            return
        
        if is_core_task:
            self.set_task_running(True, task_name)

        thread = threading.Thread(target=self._task_wrapper, args=(task_func, task_name, is_core_task, *args), daemon=True)
        thread.start()

    def _task_wrapper(self, task_func, task_name, is_core_task, *args):
        try:
            task_func(*args)
        except Exception as e:
            self.update_status(f"{task_name} 任务执行失败: {e}")
        finally:
            if is_core_task:
                self.after(0, lambda: self.set_task_running(False))

    def install_version(self, version_id):
        self.run_task_in_thread(self._install_version_thread, "安装", version_id)

    def _install_version_thread(self, version_id):
        callback = {"setStatus": self.update_status, "setProgress": self.update_progress}
        minecraft_launcher_lib.install.install_minecraft_version(version_id, str(MINECRAFT_DIR), callback=callback)
        self.update_status(f"版本 {version_id} 安装成功！")
        self.after(0, lambda: self.refresh_version_list(select_version=version_id))

    def refresh_version_list(self, select_version=None):
        self.run_task_in_thread(self._refresh_version_list_thread, "刷新", select_version)

    def _refresh_version_list_thread(self, select_version=None):
        version_ids = [v['id'] for v in minecraft_launcher_lib.utils.get_installed_versions(str(MINECRAFT_DIR))]
        def update_ui():
            if not version_ids:
                self.version_option_menu.configure(values=[" "])
                self.version_option_menu.set("未找到任何版本，请先安装")
                self.open_install_window()
            else:
                self.version_option_menu.configure(values=version_ids)
                if select_version and select_version in version_ids:
                    self.version_option_menu.set(select_version)
                else:
                    current_val = self.version_option_menu.get()
                    if current_val not in version_ids:
                        self.version_option_menu.set(version_ids[0])
            self.update_status("版本列表刷新完毕。")
            self.on_version_select(self.version_option_menu.get())
        self.after(0, update_ui)

    def start_launch_process(self):
        self.run_task_in_thread(self._launch_thread, "启动")

    def _launch_thread(self):
        self.save_settings()
        config = self.config_manager.config
        version_id = self.version_option_menu.get()
        
        account = self.get_current_account()
        if not account:
            self.update_status("错误：请先在账户管理中添加并选择一个账户。")
            return

        game_directory = self.get_current_game_directory()
        os.makedirs(game_directory, exist_ok=True)

        options = {
            "username": account["username"], "uuid": account["uuid"], "token": "0",
            "jvmArguments": [f"-Xmx{config['memory_mb']}M"] + (config['jvm_args'].split() if config.get('jvm_args') else []),
            "gameDirectory": str(game_directory),
        }
        
        if config.get('java_path'): options["executablePath"] = config['java_path']
        
        command = minecraft_launcher_lib.command.get_minecraft_command(version_id, str(MINECRAFT_DIR), options)
        
        self.after(0, self.show_log_window)
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace')
        
        log_thread = threading.Thread(target=self._log_reader_thread, args=(process,), daemon=True)
        log_thread.start()

    def show_log_window(self):
        if self.log_window is None or not self.log_window.winfo_exists():
            self.log_window = LogWindow(self)
        self.log_window.clear_logs()
        self.log_window.deiconify()

    def _log_reader_thread(self, process):
        while True:
            line = process.stdout.readline()
            if not line: break
            if self.log_window: self.log_window.add_log_message(line)
        process.wait()
        self.update_status("游戏已关闭。")
        if self.log_window: self.log_window.add_log_message("\n--- 游戏进程已结束 ---\n")
        self.after(0, lambda: self.set_task_running(False))

    def install_mod_loader(self, loader_type):
        mc_version = self.version_option_menu.get()
        if not mc_version or "未找到" in mc_version:
            messagebox.showerror("错误", "请先选择一个有效的原版游戏版本。")
            return
        task_name = f"安装{loader_type.capitalize()}"
        self.run_task_in_thread(self._install_loader_thread, task_name, loader_type, mc_version)

    def _install_loader_thread(self, loader_type, mc_version):
        # 导入仅在此函数中需要的库
        import xml.etree.ElementTree as ET
        from packaging.version import parse as parse_version

        callback = {"setStatus": self.update_status, "setProgress": self.update_progress}
        minecraft_directory_str = str(MINECRAFT_DIR)
        
        try:
            if loader_type == "fabric":
                # Fabric 的安装逻辑保持不变
                minecraft_launcher_lib.fabric.install_fabric(mc_version, minecraft_directory_str, callback=callback)
                loader_version = minecraft_launcher_lib.fabric.get_latest_loader_version()
                new_version_id = f"fabric-loader-{loader_version}-{mc_version}"
                self.update_status(f"Fabric {loader_version} for {mc_version} 安装成功！")
                self.after(0, lambda: self.refresh_version_list(select_version=new_version_id))
            
            elif loader_type == "forge":
                # --- 最终版：兼容新旧 Forge API 的智能安装逻辑 ---
                self.update_status(f"正在为 {mc_version} 选择合适的Forge API...")

                forge_version_to_install = None
                mc_version_parsed = parse_version(mc_version)

                # 1. 智能判断使用哪个 API
                # 1.20.2 是新旧 API 的分界线
                if mc_version_parsed >= parse_version("1.20.2"):
                    # --- 使用新的 NeoForged Maven API (适用于 1.20.2+) ---
                    self.update_status(f"检测到新版本, 使用 NeoForged API...")
                    # 新的URL结构
                    NEOFORGE_MAVEN_URL = f"https://maven.neoforged.net/net/minecraftforge/forge/maven-metadata.xml"
                    response = requests.get(NEOFORGE_MAVEN_URL )
                    response.raise_for_status()

                    root = ET.fromstring(response.content)
                    versions = []
                    for version_tag in root.findall(".//version"):
                        version_text = version_tag.text
                        # 筛选出与当前MC版本匹配的、非快照的版本
                        if version_text and version_text.startswith(mc_version) and "snapshot" not in version_text.lower():
                            versions.append(version_text)
                    
                    if not versions:
                        raise Exception(f"在 NeoForged API 中未找到适用于 {mc_version} 的稳定版 Forge。")
                    
                    # 选择最新的版本
                    forge_version_to_install = max(versions, key=parse_version)

                else:
                    # --- 使用旧的 files.minecraftforge.net API (适用于 1.20.1 及更早) ---
                    self.update_status(f"检测到旧版本, 使用传统 API...")
                    FORGE_JSON_URL = f"https://files.minecraftforge.net/net/minecraftforge/forge/index_{mc_version}.json"
                    response = requests.get(FORGE_JSON_URL )
                    response.raise_for_status()
                    data = response.json()

                    promo_key_recommended = f"{mc_version}-recommended"
                    promo_key_latest = f"{mc_version}-latest"
                    build_number = data.get("promos", {}).get(promo_key_recommended) or data.get("promos", {}).get(promo_key_latest)

                    if not build_number:
                        latest_build = max(data["builds"], key=lambda x: x.get("build", 0))
                        build_number = latest_build.get("build")
                    
                    if not build_number:
                        raise Exception(f"在传统 API 中无法确定要安装的 Forge 版本。")
                    
                    forge_version_to_install = f"{mc_version}-{build_number}"

                # 2. 执行安装
                if not forge_version_to_install:
                    raise Exception("未能确定任何可安装的 Forge 版本。")

                self.update_status(f"已选择版本: {forge_version_to_install}，开始安装...")
                minecraft_launcher_lib.forge.install_forge_version(forge_version_to_install, minecraft_directory_str, callback=callback)
                
                self.update_status(f"Forge {forge_version_to_install} 安装成功！")
                self.after(0, lambda: self.refresh_version_list(select_version=forge_version_to_install))

        except Exception as e:
            self.update_status(f"安装{loader_type.capitalize()}失败: {e}")
        finally:
            self.after(0, lambda: self.set_task_running(False))

    def open_mod_market(self):
        selected_version = self.version_option_menu.get()
        if not selected_version or "未找到" in selected_version:
            messagebox.showerror("错误", "请先选择一个有效的游戏版本。")
            return

        game_dir = self.get_current_game_directory()
        if not game_dir: return

        mc_version_clean = None
        
        # --- 增强的解析逻辑 ---
        # 策略一：首先尝试使用官方库解析，它对Fabric等标准整合包很有效
        try:
            mc_version_clean = minecraft_launcher_lib.utils.get_version_from_version_id(selected_version)["id"]
        except Exception:
            # 策略二：如果官方库失败，则启用正则表达式作为终极备用方案
            import re # 仅在此处导入re模块
            match = re.search(r"(\d+\.\d+(\.\d+)?)", selected_version)
            if match:
                mc_version_clean = match.group(0)

        # 如果两种策略都失败了，才向用户报错
        if not mc_version_clean:
            messagebox.showerror("错误", "无法从此版本ID中解析出纯净的Minecraft版本号 (例如 '1.19.2')。\nMod市场需要此信息。")
            return
        # --- 逻辑增强结束 ---

        if self.mod_market_window is None or not self.mod_market_window.winfo_exists():
            self.mod_market_window = ModMarketWindow(self, mc_version_clean, game_dir / "mods")
            self.mod_market_window.focus() # 确保新窗口获得焦点
        else:
            # 如果窗口已存在，检查其MC版本是否与当前选择一致
            if self.mod_market_window.mc_version == mc_version_clean:
                self.mod_market_window.focus() # 版本一致，直接显示
            else:
                # 版本不一致，销毁旧窗口，创建新窗口
                self.mod_market_window.destroy()
                self.mod_market_window = ModMarketWindow(self, mc_version_clean, game_dir / "mods")
                self.mod_market_window.focus()

    def load_settings(self):
        config = self.config_manager.config
        self.java_path_entry.insert(0, config.get("java_path", ""))
        self.memory_entry.insert(0, str(config.get("memory_mb", "")))
        self.jvm_args_entry.insert(0, config.get("jvm_args", ""))

    def save_settings(self):
        self.config_manager.set("java_path", self.java_path_entry.get())
        try:
            self.config_manager.set("memory_mb", int(self.memory_entry.get()))
        except (ValueError, TypeError):
            self.config_manager.set("memory_mb", self.config_manager.default_config["memory_mb"])
        self.config_manager.set("jvm_args", self.jvm_args_entry.get())
        self.config_manager.save()
        self.update_status("设置已保存！")

    def get_current_account(self):
        selected_uuid = self.config_manager.get("selected_account_uuid")
        accounts = self.config_manager.get("accounts", [])
        return next((acc for acc in accounts if acc["uuid"] == selected_uuid), None)

    def update_account_list(self):
        self.account_listbox.delete(0, 'end')
        accounts = self.config_manager.get("accounts", [])
        account_names = []
        if accounts:
            account_names = [acc["username"] for acc in accounts]
            for name in account_names:
                self.account_listbox.insert('end', name)
        
        self.account_menu.configure(values=account_names if account_names else ["无账户"])
        
        current_account = self.get_current_account()
        if current_account:
            self.account_menu.set(current_account["username"])
            try:
                idx = account_names.index(current_account["username"])
                self.account_listbox.selection_set(idx)
            except ValueError:
                pass # 如果找不到就不选中
        elif account_names:
            self.account_menu.set(account_names[0])
            self.account_listbox.selection_set(0)
        else:
            self.account_menu.set("无账户")
            self.account_menu.configure(state="disabled")

    def switch_account(self, selected_name):
        accounts = self.config_manager.get("accounts", [])
        account = next((acc for acc in accounts if acc["username"] == selected_name), None)
        if account:
            self.config_manager.set("selected_account_uuid", account["uuid"])
            self.update_status(f"已切换到账户: {selected_name}")
            self.config_manager.save() # 切换后立即保存
            self.update_account_list()

    def add_account(self):
        username = self.new_account_entry.get()
        if not username:
            messagebox.showwarning("提示", "请输入玩家名！")
            return
        if any(acc['username'] == username for acc in self.config_manager.get("accounts")):
            messagebox.showwarning("提示", "该玩家名已存在！")
            return

        new_acc = {"username": username, "uuid": str(uuid.uuid4())}
        self.config_manager.config["accounts"].append(new_acc)
        self.new_account_entry.delete(0, 'end')
        self.config_manager.save()
        self.update_account_list()
        self.update_status(f"已添加账户: {username}")

    def remove_account(self):
        selected_indices = self.account_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("提示", "请在列表中选择一个要删除的账户！")
            return
        
        index = selected_indices[0]
        username = self.config_manager.get("accounts")[index]["username"]
        
        if messagebox.askyesno("确认", f"确定要删除账户 {username} 吗？\n这个操作不可撤销。"):
            removed_account = self.config_manager.config["accounts"].pop(index)
            
            # 如果删除的是当前选中的账户，则自动选择新的账户
            if removed_account["uuid"] == self.config_manager.get("selected_account_uuid"):
                if self.config_manager.get("accounts"):
                    self.config_manager.set("selected_account_uuid", self.config_manager.get("accounts")[0]["uuid"])
                else:
                    self.config_manager.set("selected_account_uuid", None)

            self.config_manager.save()
            self.update_account_list()
            self.update_status(f"已删除账户: {username}")

    def select_java_path(self):
        path = filedialog.askopenfilename(title="选择 Java 可执行文件", filetypes=[("Java Executable", "java.exe"), ("All files", "*.*")])
        if path:
            self.java_path_entry.delete(0, 'end')
            self.java_path_entry.insert(0, path)

if __name__ == "__main__":
    # 设置UI外观
    customtkinter.set_appearance_mode("System")
    customtkinter.set_default_color_theme("blue")
    
    # 创建并运行App
    app = App()
    app.mainloop()
